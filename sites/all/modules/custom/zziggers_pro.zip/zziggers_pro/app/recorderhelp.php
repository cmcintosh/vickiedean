<?php
   header( 'Location: recorderhelp.pdf' ) ;
?>



