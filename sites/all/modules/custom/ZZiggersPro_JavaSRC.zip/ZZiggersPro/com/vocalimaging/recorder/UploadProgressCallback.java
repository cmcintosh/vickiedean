package com.vocalimaging.recorder;

public interface UploadProgressCallback {

    public void uploadUpdated(double progress);
    
}
